import os

from .maximum import MapReduce_Maximum
from .minimum import MapReduce_Minimum