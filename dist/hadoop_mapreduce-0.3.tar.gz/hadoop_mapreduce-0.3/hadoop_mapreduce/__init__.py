import os
import re
import string

from .maximum import MapReduce_Maximum
from .minimum import MapReduce_Minimum
from .wordcount import MapReduce_Wordcount